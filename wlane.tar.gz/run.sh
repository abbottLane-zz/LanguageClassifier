#!/bin/sh

mono Classifier.exe
