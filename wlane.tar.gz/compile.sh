#!/bin/sh

gmcs Classifier.cs
