William Lane
8/28/15
Ling 473 
Project 5 ReadMe


	My approach to the language classification problem was to first read all the language models into memory as LanguageModel objects. Next, I read the input lines one at a time and calulated the probability of each of the 15 languages given the string of words in the input. The math for this was explained clearly on the assignment sheet, so I had no trouble taking the reduced bayes theorem equation and translating it to code:

	foreach (string word in words) {
		runningProbability += ((Math.Log10 (l.getTotalOccurencesOfWord (word))) - (Math.Log10(l.getTotalOccurancesInAModel ())))/10;
	}

	*Note: I divide the running probability numbers by 10 just as a way to
reduce the size of my final scores accross the board. It made it easier to
quickly compare numbers visually and verify my results.

	The only trick here seemed to be in how I chose to handle the smoothing value, for handling cases where the word examined did not exist in the language model. This has the potential to happen a lot, even if the word did belong to the language, simply because the model can't contain every word in a language. At first, my smoothing technique was to give every word the benefit of the doubt and assign it a value of 1 occurence in the language, even if I could not find any occurence. However I found this technique to cause a lot of data noise which caused my program to predict innacurately in some cases. The problem seemed to be related to the division of total word representations contained in a given model. There are some models like SWH and GLA whose 1500 most common words totalled to vastly fewer words than say English's totals. That means when we are giving an unknown token a value of 1, and dividing by the total word counts for SWH or GLA, these languages came out with unfairly weighted scores compared to all other languages. This caused an over-abundence of GLA and SWH predictions. In the end, I decided that the smoothing value for words that could not be found should be a virtual zero, so as not to give unfair weight to clearly unrelated languages. The flip side of this decision is that languages who are just naturally very lexically diverse and for whom 1500 words just isn't enough to catch a large portion of their lexical items, these languages miss out on points that rightfully belong to them even though their model can't prove it. But in the end, relying on a lot of the common function words that are contained in the model seems to be enough to accurately identify a language. So everytime I came accross a word that couldn't be found in a model, I assigned it an occurence of .0001: basically non-occuring. I couldn't do 0 outright, because 0 divided by anything results in a -Infinity in c#.    

	This project was a lot of fun, and I was particularly interested in seeing how the original Bayes formula broke down to accomodate the problem. It was also fun experimenting with smoothing techniques to see how the language model could be manipulated to optimize our solution.
